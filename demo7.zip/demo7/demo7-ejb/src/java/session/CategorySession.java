/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package session;

import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import model.Category;

/**
 *
 * @author PC
 */
@Stateless
@LocalBean
public class CategorySession {

    @PersistenceContext
    private EntityManager em;

    public List<Category> findAll() {
        return em.createQuery("select a from Category a")
                .getResultList();
    }
}
